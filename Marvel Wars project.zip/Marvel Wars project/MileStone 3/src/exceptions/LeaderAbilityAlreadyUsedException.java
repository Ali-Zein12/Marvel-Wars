package exceptions;

public class LeaderAbilityAlreadyUsedException extends GameActionException {

	public LeaderAbilityAlreadyUsedException() {
		// TODO Auto-generated constructor stub
	}

	public LeaderAbilityAlreadyUsedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
