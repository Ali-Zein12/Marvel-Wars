package exceptions;

public class UnallowedMovementException extends GameActionException {

	public UnallowedMovementException() {
		// TODO Auto-generated constructor stub
	}

	public UnallowedMovementException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
