package exceptions;

public class NotEnoughResourcesException extends GameActionException {

	public NotEnoughResourcesException() {
		// TODO Auto-generated constructor stub
	}

	public NotEnoughResourcesException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
