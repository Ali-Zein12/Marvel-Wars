package exceptions;

public class AbilityUseException extends GameActionException {

	public AbilityUseException() {
		// TODO Auto-generated constructor stub
	}

	public AbilityUseException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
