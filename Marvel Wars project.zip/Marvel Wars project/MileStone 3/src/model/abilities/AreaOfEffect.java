package model.abilities;

public enum AreaOfEffect {
	SINGLETARGET, TEAMTARGET, SELFTARGET, DIRECTIONAL, SURROUND

}
