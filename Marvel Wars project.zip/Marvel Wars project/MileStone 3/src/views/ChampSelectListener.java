package views;

public interface ChampSelectListener {

}
